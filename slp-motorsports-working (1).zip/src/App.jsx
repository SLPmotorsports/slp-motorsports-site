// SLP Motorsports – single‑page React component with reviews carousel, photo gallery and placeholder car‑sales section
import React, { useState } from "react";
import { motion } from "framer-motion";

export default function App() {
  const logoSrc = "https://placehold.co/240x120?text=SLP+Logo"; // TODO: replace with real logo URL

  const services = [
    { title: "Exhaust System Upgrades", desc: "Custom exhaust fabrication and bolt‑on systems for performance, sound and efficiency." },
    { title: "Full Diagnostics", desc: "Advanced computer diagnostics for all makes and models to pinpoint issues quickly and accurately." },
    { title: "Electrical System Repairs", desc: "Battery, alternator, wiring and full electrical troubleshooting to keep your car reliable." },
    { title: "Cooling System Service", desc: "Radiators, hoses, pumps and coolant flushes to keep temps under control." },
    { title: "Oil & Fluid Service", desc: "High‑quality synthetic oils, fast changes and complete fluid maintenance." },
    { title: "Suspension Upgrades", desc: "Coil‑overs, lift / lowering kits and bushings for comfort or track handling." },
    { title: "AC & Climate", desc: "Recharge, compressor replacement and full HVAC repairs that keep you cool." },
    { title: "Windshield Services", desc: "Chip repairs and full replacements using OEM‑grade glass." },
    { title: "Performance Mods", desc: "Expert bolt‑on upgrades, no dyno required." },
    { title: "Custom Fabrication", desc: "Turbo kits, exhaust headers and more – built in‑house to spec." },
    { title: "Restoration & Builds", desc: "Ground‑up builds or refreshes with modern power." },
    { title: "Brake Services", desc: "Pads, rotors and full big‑brake upgrades for safety and bite." },
    { title: "Alignment & Calibration", desc: "Precision alignment and sensor calibration for perfect handling." },
    { title: "Wheels & Tires", desc: "Mount, balance and install all major brands." },
    { title: "Window Tinting", desc: "Premium film applied by certified installers." }
  ];

  return (
    <main className="p-10 text-white">
      <h1 className="text-yellow-400 text-4xl font-bold text-center">SLP Motorsports</h1>
      <p className="text-center mt-4 text-lg">Your one-stop auto performance shop in New Orleans</p>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
        {services.map(({ title, desc }, idx) => (
          <div key={idx} className="bg-purple-800 border border-yellow-400 p-4 rounded-lg shadow">
            <h3 className="text-yellow-300 font-semibold text-lg">{title}</h3>
            <p className="text-sm">{desc}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
